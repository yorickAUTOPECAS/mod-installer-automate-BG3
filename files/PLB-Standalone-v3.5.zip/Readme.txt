Party Limit Begone by Sildur:
https://www.nexusmods.com/baldursgate3/mods/327

Installation (Standalone version, recommended):
1. Download and unzip the standalone version.
2. Drag and drop the entire mods folder in to your baldurs gate 3 data folder. (example: \steamapps\common\Baldurs Gate 3\Data)
3. That's it, enjoy the game! Note: Dismiss one party member if you already have 4, this will reset the party limit and set it to 16.

Known Bugs (READ ME):
- Grymforge Map transition: Reduce your party size to 4 members before sailing with the boat. If you already used it and your characters are stuck, dismiss the ones that are with you and sail back and forth to unstuck the rest. Note: After using the boat a timed quest is triggered and going to camp will progess it.
- Some quest or important items aren't registered correctly if they are carried by a fifth or higher party member. So make sure your first 4 party members carry any important items.
- Camp sleeping bug: Use one of the awake companions and talk to Lae'zel, use a camp chest or reduce your party size to 4 before resting.
- Some ingame events are simply hardcoded for 4 party members and will glitch out. This is usually solved by either dismissing the additional members/players or by teleporting back and forth.

Uninstall Standalone version:
Delete the Mods folder inside your Data folder, that's it.