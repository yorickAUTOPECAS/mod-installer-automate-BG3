@echo off
title Party Limit Begone Multiplayer Patch
echo Baldurs Gate 3 Multiplayer Patch by Sildur
echo https://www.nexusmods.com/baldursgate3/mods/327/

Set "GetFileName=%~n1.exe"
Set "GetPatcherPath=%~dp0PatchFiles"
copy /y "%GetFileName%" "%GetFileName%.backup"

if exist "%GetFileName%.backup" "%GetPatcherPath%\XVI32.exe" "%GetFileName%" /S="%GetPatcherPath%\PLB-MP-Patch.xsc"