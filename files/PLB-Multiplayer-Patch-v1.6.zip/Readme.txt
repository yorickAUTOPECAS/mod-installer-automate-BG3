Party Limit Begone by Sildur:
https://www.nexusmods.com/baldursgate3/mods/327

Multiplayer Patch Installation:
1. First follow one of the mod installations up above. Then download the multiplayer patch and unzip it.
2. Drag and drop either your bg3.exe or bg3_dx11.exe file onto the PartyLimitBegonePatcher.bat file. It will create a backup for you.
3. That's it! Enjoy the game.
Note: bg3.exe is used if vulkan is selected in the larian launcher and bg_dx11.exe if directx is selected instead. Windows defender might flag it on some systems but it's safe to use, nexusmods scans every upload. I changed it multiple times but after a while defender starts acting up again. So just allow it and move on.

Linux and Mac support:
PLB is supported by both linux and mac but the MP patch is tricky to install, the easiest solution would be for a friend to send you their patched exe file. Otherwise you must edit the PartyLimitBegonePatcher.bat file with any text editor and change this line: Set "GetFileName=%~n1.exe" to something like Set "GetFileName=bg3.exe" then place your bg3.exe file next to it - in to the same folder and run the PartyLimitBegonePatcher.bat file with wine﻿.

Console/Crossplay support:
PLB standalone works with console players if the hosting player is on PC.
Only 3 console players are supported and they must join first because only PC players can join after 4 slots are already taken. (host + 3 console players)
Player 5+ can only join via lan mode or if the host opens port 23253 they can type the host IP in to the direct code box to join. For lan mode install something like hamachi and have the hosting players and player 5+ in the same hamachi network. The hosting player must also enable "lan connection" in options -> gameplay.
To continue an existing crossplay save with more than 4 players you have to create a new fresh lobby have everyone join and start a new game. Once ingame you can load your old main save. This will create new saves so the hosting player should probably clear them out every now and then.

Uninstall MP Patch:
Delete the patched exe file and restore your backup. The patcher creates a bg3.exe.backup (or bg3_dx11.exe.backup) file in your game folder, simply rename it back to bg3.exe. (or bg3_dx11.exe)